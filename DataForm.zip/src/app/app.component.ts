import { Component, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
   currentindex : number = -1
  isUpdate:boolean = false;
  list : any
  Id : any
  id : any
  users : any;
  @ViewChild('myform')
  myform !: NgForm;
  title = 'DataForm';

  constructor(){
    this.model.inputbranch="";
  }
  ngOnInit(){
    this.users = JSON.parse(localStorage.getItem("Users")!)
  }
  
  numberOnly(event: { which: any; keyCode: any; }): boolean {
    const charCode = (event.which) ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;

  }
// Validation Method
  validate(): boolean{
    var patterns ={
      fname : /^[a-z. A-Z]{1,27}$/,
      email : /^[a-zA-Z0-9+_.-]+@[a-zA-Z.-]+$/,
      phone : /^[6-9][0-9]{9}$/,
     adrs : /^[A-Za-z0-9/ :-]{5,30}$/
   }
   if(!patterns.fname.test(this.model.fname)){
       alert("Name is not valid")
       return false;
   }else{
     if(!patterns.email.test(this.model.email)){
       alert("Email is not Valid")
       return false;
     }else{
       if(!patterns.phone.test(this.model.phone)){
         alert("Invalid Phone Number")
         return false;
       }else{
         if(this.model.inputbranch==""){
           alert("Please Select One Branch")
           return false;
         }else{
            if(!patterns.adrs.test(this.model.adrs)){
              alert("Enter a Valid Address")
              return false
            }else{
              if(this.model.gender==""){
                alert("Please Select Gender")
                return false;
              }else{
                return true;
              }
            }
         }
       }
     }
   }
   return true;
  }
// Submit Method
  onSubmit()
  {
    if(this.validate()== true){
      let users =[];
      users = JSON.parse(localStorage.getItem("Users")!) || [];
    users.push({
      "fname":this.model.fname,
      "email": this.model.email,
      "phone":this.model.phone,
      "Branch":this.model.inputbranch,
      "adrs": this.model.adrs,
      "Gender": this.model.gender
     } ) 
    this.users = users
    localStorage.setItem("Users", JSON.stringify(users));
    this.myform.reset(this.myform);
    }
  }
 //Delete User 
  DeleteUser(id: any){
    var del = confirm("Do u want to delete?")
    if(del == true){
     let res = this.users[id]
     res = this.users.splice(id,1);
     localStorage.setItem("Users",JSON.stringify(this.users));
    }
  };
  // Edit User
  onEdit(Id:any){
    this.isUpdate = true;
   let list = this.users[Id]
   
    this.model.fname = list.fname,
    this.model.email = list.email,
    this.model.phone = list.phone,
    this.model.inputbranch = list.Branch,
    this.model.adrs = list.adrs,
    this.model.gender=list.Gender
    this.currentindex = Id
    }
  onUpdate(){  
      if(this.validate() == true){
      let obj:any ={
      "fname":this.model.fname,
      "email": this.model.email,
      "phone":this.model.phone,
      "Branch":this.model.inputbranch,
      "adrs": this.model.adrs,
      "Gender": this.model.gender
      } 
     if(this.currentindex == -1){
       alert("User Not Found")
     }else{
       this.users[this.currentindex] = obj
       localStorage.setItem("Users",JSON.stringify(this.users));
       alert("user updated Successfully")
       this.myform.resetForm();
       this.isUpdate = false;
       this.currentindex = -1;
     }
    }   
    }
    
  model : signup = new signup(); 
  }
class signup {
  constructor(public fname : string ="",
              public email : string="",
              public phone : string="",
              public inputbranch:string="",
              public adrs : string="",
              public gender : string="") {  
}
}