import { MydirectiveDirective } from './mydirective.directive';

describe('MydirectiveDirective', () => {
  it('should create an instance', () => {
    const directive = new MydirectiveDirective();
    expect(directive).toBeTruthy();
  });
});
